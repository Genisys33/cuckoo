import sys
import os
pardir = os.path.abspath(os.path.join(__file__, os.path.pardir))
sys.path.append(os.path.dirname(pardir))

# cwd = os.path.abspath(os.path.dirname(__file__))
# os.environ['IRMA_FRONTEND_CFG_PATH'] = cwd
