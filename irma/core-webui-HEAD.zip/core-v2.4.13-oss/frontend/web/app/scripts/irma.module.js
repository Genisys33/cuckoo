(function () {
  angular
    .module('irma', [
      'ngResource',
      'ngSanitize',
      'ngRoute',
      'angularFileUpload',
      'mgcrea.ngStrap',
      'mgcrea.ngStrap.helpers.dimensions',
      'jsonFormatter',
      'puigcerber.capitalize',
      'angularMoment',
      'ngTable',
      'ngTagsInput',
      'angular-svg-round-progressbar',
    ]);
}());
