Disclaimer
----------

IRMA is distributed as it is, in the hope that it will be useful, but without
any warranty neither the implied merchantability or fitness for a particular
purpose.

Whatever you do with this tool is uniquely your own responsibility.

License
-------

IRMA source code is licensed under Apache License, version 2.0.

The full license text can be found below (:ref:`irma-license`).

.. _irma-license:

Apache License, version 2.0
---------------------------

.. include:: ../../LICENSE
    :literal:
