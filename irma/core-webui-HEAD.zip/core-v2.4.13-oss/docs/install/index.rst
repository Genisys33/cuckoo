Installation
============

This chapter describes the methods available to install IRMA using Ansible
scripts.

.. toctree::
   requirements.rst
   automated/index.rst
