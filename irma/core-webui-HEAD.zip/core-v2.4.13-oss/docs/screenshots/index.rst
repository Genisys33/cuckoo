Screenshots
===========

Command Line Interface
----------------------

A sample script can be found in frontend repository. Add your own frontend address before testing it.

.. image:: cli/irma_cli.png
   :alt: Command Line Interface

Web Interface
-------------

Some screenshots of the irma user interface shipped with frontend package.

.. image:: webui/webui1.png
   :alt: File Upload Interface

.. image:: webui/webui2.png
   :alt: Uploading ...

.. image:: webui/webui3.png
   :alt: Scanning ...

.. image:: webui/webui4.png
   :alt: Scan Details

.. image:: webui/webui5.png
   :alt: Scan Details suite
