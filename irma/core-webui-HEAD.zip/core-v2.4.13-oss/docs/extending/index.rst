Extending IRMA
--------------

.. toctree::

   add_probe.rst
