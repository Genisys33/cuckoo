Environment configuration
=========================
Conf VMs with choice of probes
