Components configuration
========================

.. toctree::
   frontend.rst
   brain.rst
   probe.rst
