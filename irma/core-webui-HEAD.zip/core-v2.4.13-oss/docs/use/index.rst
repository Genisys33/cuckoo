Use IRMA
========

There are 2 ways to use IRMA :

.. toctree::
   :maxdepth: 2

   webui/index.rst
   cli/index.rst
