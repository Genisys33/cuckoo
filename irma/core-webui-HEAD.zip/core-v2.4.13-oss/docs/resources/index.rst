Resources
=========

* `Project website <http://irma.quarkslab.com>`_
* `IRC <irc://irc.freenode.net/qb_irma>`_  (irc.freenode.net, #qb_irma)
* `Twitter <https://twitter.com/qb_irma>`_ (@qb_irma)
