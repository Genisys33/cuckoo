#### Activation of Licence from a activation code
During the acquisition of a Kaspersky license a activation code is given.
With this one, the license can be activated on https://activation.kaspersky.com/en/.
The activation keys are then sent by mail.
